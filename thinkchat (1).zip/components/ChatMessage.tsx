import React from 'react';
import { Message, Role } from '../types';
import { ThinkChatIcon } from './icons/ThinkChatIcon';
import { UserIcon } from './icons/UserIcon';
import { StudentIcon } from './icons/StudentIcon';
import { SellerIcon } from './icons/SellerIcon';
import { DeveloperIcon } from './icons/DeveloperIcon';

interface ChatMessageProps {
  message: Message;
  profession: string | null;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message, profession }) => {
  const isModel = message.role === Role.MODEL;

  // Renders content by converting markdown for lists and bold text into HTML elements.
  const renderFormattedContent = (content: string) => {
    // First